// Mock data for the CarbonTrade application

export interface ChartData {
  name: string;
  value: number;
}

export interface SuggestedZone {
  name: string;
  description: string;
  sequestration: string;
  mapsUrl: string;
}

export interface EcosystemInfo {
  id: string;
  name: string;
  icon: string;
  species: string[];
  economicBenefits: string;
  growthMaturity: string;
  carbonSequestration: string;
  plantingZones: string;
  color: string;
}

export interface RewardBadge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
}

export interface ActivityItem {
  id: string;
  type: "success" | "trade" | "submission";
  message: string;
  time: string;
  icon: string;
  color: string;
}

// Regional carbon levels chart data
export const regionalCarbonData: ChartData[] = [
  { name: "West Bengal", value: 120 },
  { name: "Tamil Nadu", value: 95 },
  { name: "Kerala", value: 140 },
  { name: "Goa", value: 85 },
  { name: "Karnataka", value: 160 },
  { name: "Andhra P.", value: 110 },
];

// Suggested plantation zones
export const suggestedZones: SuggestedZone[] = [
  {
    name: "Coastal Andhra Pradesh",
    description: "Mangrove restoration project",
    sequestration: "45 tons/hectare/year",
    mapsUrl: "https://maps.google.com/?q=Coastal+Andhra+Pradesh",
  },
  {
    name: "Western Ghats, Kerala",
    description: "Seagrass meadow restoration",
    sequestration: "38 tons/hectare/year",
    mapsUrl: "https://maps.google.com/?q=Western+Ghats+Kerala",
  },
  {
    name: "Sundarbans, West Bengal",
    description: "Salt marsh restoration",
    sequestration: "52 tons/hectare/year",
    mapsUrl: "https://maps.google.com/?q=Sundarbans+West+Bengal",
  },
];

// Ecosystem information for suggested plantations
export const ecosystems: EcosystemInfo[] = [
  {
    id: "mangroves",
    name: "Mangrove Forests",
    icon: "trees",
    species: ["Rhizophora", "Avicennia", "Bruguiera"],
    economicBenefits: "Coastal protection, fisheries support, tourism revenue, and carbon credit income. Mangroves provide natural barriers against storms and tsunamis.",
    growthMaturity: "Fast initial growth (2-3 years to establish), reaches full carbon sequestration capacity in 5-7 years. Lifespan of 50-100 years.",
    carbonSequestration: "45-60 tons CO₂e per hectare per year. Stores carbon in both above and below-ground biomass plus sediments.",
    plantingZones: "Intertidal zones, estuaries, coastal lagoons. Requires saltwater exposure and muddy/sandy substrates with low wave energy.",
    color: "green",
  },
  {
    id: "seagrass",
    name: "Seagrass Meadows",
    icon: "waves",
    species: ["Zostera", "Posidonia", "Thalassia"],
    economicBenefits: "Marine biodiversity support, coastal erosion control, water quality improvement, and recreational fishing enhancement.",
    growthMaturity: "Moderate growth rate, establishes in 2-4 years, full maturity in 3-5 years. Requires careful monitoring during establishment phase.",
    carbonSequestration: "35-45 tons CO₂e per hectare per year. Excellent sediment carbon storage capacity, particularly effective in shallow waters.",
    plantingZones: "Shallow coastal waters (1-10m depth), sandy or muddy bottoms, good water circulation, moderate wave protection required.",
    color: "blue",
  },
  {
    id: "saltmarsh",
    name: "Tidal Salt Marshes",
    icon: "mountain",
    species: ["Spartina", "Salicornia", "Atriplex"],
    economicBenefits: "Storm surge protection, water filtration, wildlife habitat, recreational opportunities, and sustainable harvesting of salt-tolerant crops.",
    growthMaturity: "Rapid establishment (1-2 years), full carbon potential in 3-4 years. Highly resilient once established, adapts well to changing conditions.",
    carbonSequestration: "50-65 tons CO₂e per hectare per year. Highest carbon storage rate among blue carbon ecosystems, excellent soil carbon accumulation.",
    plantingZones: "Upper intertidal zones, areas with regular but not daily flooding, muddy soils with high organic content, protected coastal areas.",
    color: "purple",
  },
];

// Reward badges
export const rewardBadges: RewardBadge[] = [
  {
    id: "first-plantation",
    name: "First Plantation",
    description: "Completed your first project",
    icon: "award",
    color: "green",
  },
  {
    id: "carbon-champion",
    name: "Carbon Champion",
    description: "Sequestered 100+ tons CO₂e",
    icon: "trophy",
    color: "blue",
  },
  {
    id: "active-trader",
    name: "Active Trader",
    description: "Completed 10+ trades",
    icon: "star",
    color: "purple",
  },
  {
    id: "community-builder",
    name: "Community Builder",
    description: "Invited 5+ new members",
    icon: "users",
    color: "amber",
  },
];

// Recent activity items
export const recentActivity: ActivityItem[] = [
  {
    id: "activity-1",
    type: "success",
    message: 'Project "Kerala Mangrove Restoration" approved',
    time: "2 hours ago",
    icon: "check",
    color: "green",
  },
  {
    id: "activity-2",
    type: "trade",
    message: "Sold 25 C-BLUE tokens at ₹875 each",
    time: "1 day ago",
    icon: "trending-up",
    color: "blue",
  },
];

// Market data
export const marketPrice = 875;
export const marketVolume = 1245;

// Current user mock data
export const currentUser = {
  id: "test-user-1",
  name: "John Doe",
  email: "john.doe@example.com",
  avatar: "JD",
  role: "individual",
  walletBalance: 45280,
  carbonCredits: 78,
};
