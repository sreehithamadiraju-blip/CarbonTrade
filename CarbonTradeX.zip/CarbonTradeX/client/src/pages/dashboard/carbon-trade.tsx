import { useState, useEffect } from "react";
import { ArrowDown, ArrowUp, Wallet, TrendingUp, BarChart, Leaf } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "./layout";
import { marketPrice, marketVolume, currentUser } from "@/lib/data";

const mockTransactions = [
  {
    id: "1",
    type: "buy",
    amount: 25,
    value: 21875,
    date: "Jan 20",
    status: "completed",
  },
  {
    id: "2",
    type: "sell",
    amount: 15,
    value: 13125,
    date: "Jan 18",
    status: "completed",
  },
];

export default function CarbonTrade() {
  const [buyAmount, setBuyAmount] = useState<number>(0);
  const [sellAmount, setSellAmount] = useState<number>(0);
  const [estimatedBuyCost, setEstimatedBuyCost] = useState<number>(0);
  const [estimatedSellRevenue, setEstimatedSellRevenue] = useState<number>(0);

  // Calculate estimated cost for buying
  useEffect(() => {
    setEstimatedBuyCost(buyAmount * marketPrice);
  }, [buyAmount]);

  // Calculate estimated revenue for selling
  useEffect(() => {
    setEstimatedSellRevenue(sellAmount * marketPrice);
  }, [sellAmount]);

  const handleBuyOrder = () => {
    console.log("Buy order:", { amount: buyAmount, cost: estimatedBuyCost });
    setBuyAmount(0);
  };

  const handleSellOrder = () => {
    console.log("Sell order:", { amount: sellAmount, revenue: estimatedSellRevenue });
    setSellAmount(0);
  };

  return (
    <DashboardLayout title="Carbon Trading">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card className="bg-card border-border" data-testid="wallet-balance-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Wallet Balance</p>
                <p className="text-2xl font-bold text-foreground">₹{currentUser.walletBalance.toLocaleString()}</p>
              </div>
              <Wallet className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border" data-testid="market-price-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Market Price</p>
                <p className="text-2xl font-bold text-foreground">₹{marketPrice} / C-BLUE</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border" data-testid="volume-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Volume (24h)</p>
                <p className="text-2xl font-bold text-foreground">{marketVolume.toLocaleString()}</p>
              </div>
              <BarChart className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border" data-testid="credits-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Your Credits</p>
                <p className="text-2xl font-bold text-foreground">{currentUser.carbonCredits} C-BLUE</p>
              </div>
              <Leaf className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto" data-testid="transactions-table">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-muted-foreground">Type</TableHead>
                    <TableHead className="text-muted-foreground">Amount</TableHead>
                    <TableHead className="text-muted-foreground">Value</TableHead>
                    <TableHead className="text-muted-foreground">Date</TableHead>
                    <TableHead className="text-muted-foreground">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockTransactions.map((transaction) => (
                    <TableRow key={transaction.id} data-testid={`transaction-${transaction.id}`}>
                      <TableCell>
                        <div className="flex items-center">
                          {transaction.type === "buy" ? (
                            <ArrowDown className="w-4 h-4 text-green-500 mr-2" />
                          ) : (
                            <ArrowUp className="w-4 h-4 text-red-500 mr-2" />
                          )}
                          <span className="text-sm text-foreground capitalize">{transaction.type}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-foreground">
                        {transaction.amount} C-BLUE
                      </TableCell>
                      <TableCell className="text-sm text-foreground">
                        ₹{transaction.value.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {transaction.date}
                      </TableCell>
                      <TableCell>
                        <Badge className="bg-green-500/20 text-green-400">
                          {transaction.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* New Order Form */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-foreground">New Order</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="buy" className="w-full" data-testid="order-tabs">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="buy" data-testid="tab-buy">Buy</TabsTrigger>
                <TabsTrigger value="sell" data-testid="tab-sell">Sell</TabsTrigger>
              </TabsList>

              {/* Buy Form */}
              <TabsContent value="buy" className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="buy-amount" className="text-foreground">Amount (C-BLUE)</Label>
                  <Input
                    id="buy-amount"
                    type="number"
                    min="0"
                    step="0.1"
                    value={buyAmount || ""}
                    onChange={(e) => setBuyAmount(Number(e.target.value))}
                    placeholder="Enter amount"
                    className="bg-input border-border mt-2"
                    data-testid="input-buy-amount"
                  />
                </div>
                <div>
                  <Label className="text-foreground">Estimated Cost</Label>
                  <div
                    className="w-full px-3 py-2 bg-muted border border-border rounded-md text-foreground mt-2"
                    data-testid="estimated-buy-cost"
                  >
                    ₹{estimatedBuyCost.toLocaleString()}
                  </div>
                </div>
                <Button
                  onClick={handleBuyOrder}
                  disabled={buyAmount <= 0}
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-medium"
                  data-testid="button-buy-order"
                >
                  Place Buy Order
                </Button>
              </TabsContent>

              {/* Sell Form */}
              <TabsContent value="sell" className="space-y-4 mt-4">
                <div>
                  <Label htmlFor="sell-amount" className="text-foreground">Amount (C-BLUE)</Label>
                  <Input
                    id="sell-amount"
                    type="number"
                    min="0"
                    max={currentUser.carbonCredits}
                    step="0.1"
                    value={sellAmount || ""}
                    onChange={(e) => setSellAmount(Number(e.target.value))}
                    placeholder="Enter amount"
                    className="bg-input border-border mt-2"
                    data-testid="input-sell-amount"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Available: {currentUser.carbonCredits} C-BLUE
                  </p>
                </div>
                <div>
                  <Label className="text-foreground">Estimated Revenue</Label>
                  <div
                    className="w-full px-3 py-2 bg-muted border border-border rounded-md text-foreground mt-2"
                    data-testid="estimated-sell-revenue"
                  >
                    ₹{estimatedSellRevenue.toLocaleString()}
                  </div>
                </div>
                <Button
                  onClick={handleSellOrder}
                  disabled={sellAmount <= 0 || sellAmount > currentUser.carbonCredits}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-medium"
                  data-testid="button-sell-order"
                >
                  Place Sell Order
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
