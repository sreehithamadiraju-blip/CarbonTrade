import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Bell, ChevronDown, LayoutGrid, Sprout, Send, TrendingUp, BookText, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useIsMobile } from "@/hooks/use-mobile";
import { Logo } from "@/components/logo";
import { currentUser } from "@/lib/data";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
}

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutGrid },
  { name: "My Projects", href: "/dashboard/my-projects", icon: Sprout },
  { name: "Submit Project", href: "/dashboard/submit-project", icon: Send },
  { name: "Carbon Trading", href: "/dashboard/carbon-trade", icon: TrendingUp },
  { name: "Suggested Plantations", href: "/dashboard/suggested-plantations", icon: BookText },
  { name: "Profile", href: "/dashboard/profile", icon: User },
];

const mobileNavigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutGrid, label: "Dashboard" },
  { name: "Projects", href: "/dashboard/my-projects", icon: Sprout, label: "Projects" },
  { name: "Submit", href: "/dashboard/submit-project", icon: Send, label: "Submit" },
  { name: "Trade", href: "/dashboard/carbon-trade", icon: TrendingUp, label: "Trade" },
  { name: "Learn", href: "/dashboard/suggested-plantations", icon: BookText, label: "Learn" },
  { name: "Profile", href: "/dashboard/profile", icon: User, label: "Profile" },
];

export default function DashboardLayout({ children, title }: DashboardLayoutProps) {
  const [location, setLocation] = useLocation();
  const isMobile = useIsMobile();

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop Sidebar */}
      {!isMobile && (
        <div className="fixed inset-y-0 left-0 w-64 bg-sidebar border-r border-sidebar-border">
          <div className="flex flex-col h-full">
            {/* Logo */}
            <div className="flex items-center px-6 py-4 border-b border-sidebar-border">
              <Logo size="md" />
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-4 py-6 space-y-2">
              {navigation.map((item) => {
                const isActive = location === item.href;
                return (
                  <Link key={item.name} href={item.href}>
                    <a
                      className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                        isActive
                          ? "text-sidebar-accent-foreground bg-sidebar-accent"
                          : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                      }`}
                      data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.name}
                    </a>
                  </Link>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={`${!isMobile ? "ml-64" : ""} ${isMobile ? "pb-20" : ""}`}>
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-semibold text-foreground" data-testid="page-title">
              {title}
            </h1>
            <div className="flex items-center space-x-4">
              {/* Notifications */}
              <Button
                variant="ghost"
                size="sm"
                className="p-2 text-muted-foreground hover:text-foreground"
                data-testid="button-notifications"
              >
                <Bell className="w-5 h-5" />
              </Button>

              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center space-x-2 p-2 rounded-md hover:bg-accent"
                    data-testid="button-user-menu"
                  >
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                        {currentUser.avatar}
                      </AvatarFallback>
                    </Avatar>
                    <ChevronDown className="w-4 h-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setLocation("/dashboard/profile")} data-testid="menu-profile">
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/")} data-testid="menu-logout">
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-6">{children}</main>
      </div>

      {/* Mobile Bottom Navigation */}
      {isMobile && (
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border">
          <div className="grid grid-cols-6 h-16">
            {mobileNavigation.map((item) => {
              const isActive = location === item.href;
              return (
                <Link key={item.name} href={item.href}>
                  <a
                    className={`flex flex-col items-center justify-center transition-colors ${
                      isActive ? "text-foreground" : "text-muted-foreground"
                    }`}
                    data-testid={`mobile-nav-${item.name.toLowerCase()}`}
                  >
                    <item.icon className="w-5 h-5 mb-1" />
                    <span className="text-xs">{item.label}</span>
                  </a>
                </Link>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
