import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from "recharts";
import { MapPin, Check, TrendingUp, Trees, Waves, Mountain } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import DashboardLayout from "./layout";
import { regionalCarbonData, suggestedZones, recentActivity } from "@/lib/data";

const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4'];

const monthlyTrendData = [
  { month: 'Jan', carbon: 95, projects: 12 },
  { month: 'Feb', carbon: 110, projects: 15 },
  { month: 'Mar', carbon: 125, projects: 18 },
  { month: 'Apr', carbon: 140, projects: 22 },
  { month: 'May', carbon: 160, projects: 25 },
  { month: 'Jun', carbon: 175, projects: 28 },
];

export default function MainDashboard() {
  const getZoneTheme = (index: number) => {
    const themes = [
      {
        bg: "bg-gradient-to-br from-emerald-50 to-green-100 dark:from-emerald-950 dark:to-green-900",
        border: "border-emerald-200 dark:border-emerald-800",
        icon: Trees,
        iconBg: "bg-emerald-500",
        iconColor: "text-white"
      },
      {
        bg: "bg-gradient-to-br from-cyan-50 to-blue-100 dark:from-cyan-950 dark:to-blue-900",
        border: "border-cyan-200 dark:border-cyan-800",
        icon: Waves,
        iconBg: "bg-cyan-500",
        iconColor: "text-white"
      },
      {
        bg: "bg-gradient-to-br from-purple-50 to-violet-100 dark:from-purple-950 dark:to-violet-900",
        border: "border-purple-200 dark:border-purple-800",
        icon: Mountain,
        iconBg: "bg-purple-500",
        iconColor: "text-white"
      }
    ];
    return themes[index % themes.length];
  };

  return (
    <DashboardLayout title="Dashboard">
      {/* Top Row - Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Regional Carbon Levels Bar Chart */}
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-950 dark:to-indigo-900 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-blue-900 dark:text-blue-100">
              Regional Carbon Levels (Tons CO₂e)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64" data-testid="chart-carbon-levels">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={regionalCarbonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(59, 130, 246, 0.2)" />
                  <XAxis
                    dataKey="name"
                    stroke="#1e40af"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    stroke="#1e40af"
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}`}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="rounded-lg border border-blue-200 bg-white dark:bg-blue-950 p-3 shadow-lg">
                            <div className="grid grid-cols-2 gap-2">
                              <div className="flex flex-col">
                                <span className="text-xs uppercase text-blue-600 dark:text-blue-400">Region</span>
                                <span className="font-bold text-blue-900 dark:text-blue-100">{label}</span>
                              </div>
                              <div className="flex flex-col">
                                <span className="text-xs uppercase text-blue-600 dark:text-blue-400">CO₂e</span>
                                <span className="font-bold text-blue-900 dark:text-blue-100">{payload[0].value} tons</span>
                              </div>
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="value" fill="url(#blueGradient)" radius={[4, 4, 0, 0]} />
                  <defs>
                    <linearGradient id="blueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" />
                      <stop offset="100%" stopColor="#1d4ed8" />
                    </linearGradient>
                  </defs>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Pie Chart - Regional Distribution */}
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-950 dark:to-emerald-900 border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-green-900 dark:text-green-100">
              Carbon Distribution by Region
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64" data-testid="chart-carbon-pie">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={regionalCarbonData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {regionalCarbonData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="rounded-lg border border-green-200 bg-white dark:bg-green-950 p-3 shadow-lg">
                            <p className="font-semibold text-green-900 dark:text-green-100">{payload[0].name}</p>
                            <p className="text-green-700 dark:text-green-300">{payload[0].value} tons CO₂e</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Line Chart - Monthly Trends */}
        <Card className="bg-gradient-to-br from-purple-50 to-violet-100 dark:from-purple-950 dark:to-violet-900 border-purple-200 dark:border-purple-800">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-purple-900 dark:text-purple-100">
              Monthly Carbon Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64" data-testid="chart-trends">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(139, 92, 246, 0.2)" />
                  <XAxis dataKey="month" stroke="#7c3aed" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#7c3aed" fontSize={12} tickLine={false} axisLine={false} />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="rounded-lg border border-purple-200 bg-white dark:bg-purple-950 p-3 shadow-lg">
                            <p className="font-semibold text-purple-900 dark:text-purple-100">{label}</p>
                            <p className="text-purple-700 dark:text-purple-300">Carbon: {payload[0]?.value} tons</p>
                            <p className="text-purple-700 dark:text-purple-300">Projects: {payload[1]?.value}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Area type="monotone" dataKey="carbon" stroke="#8b5cf6" fill="url(#purpleGradient)" strokeWidth={3} />
                  <defs>
                    <linearGradient id="purpleGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Second Row - Colorful Plantation Zones */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-3">
          <Card className="bg-gradient-to-r from-amber-50 to-orange-100 dark:from-amber-950 dark:to-orange-900 border-amber-200 dark:border-amber-800">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-amber-900 dark:text-amber-100">
                🌱 Suggested Plantation Zones
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {suggestedZones.map((zone, index) => {
                  const theme = getZoneTheme(index);
                  const IconComponent = theme.icon;
                  
                  return (
                    <div
                      key={index}
                      className={`p-6 rounded-xl border-2 ${theme.bg} ${theme.border} transition-all hover:scale-105 hover:shadow-lg`}
                      data-testid={`zone-${index}`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-xl ${theme.iconBg} flex items-center justify-center flex-shrink-0`}>
                          <IconComponent className={`w-6 h-6 ${theme.iconColor}`} />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-bold text-lg text-gray-900 dark:text-gray-100 mb-2">{zone.name}</h4>
                          <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">{zone.description}</p>
                          <div className="bg-white dark:bg-gray-800 rounded-lg p-3 mb-3">
                            <p className="text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1">
                              CO₂ Sequestration Rate
                            </p>
                            <p className="text-sm font-bold text-gray-900 dark:text-gray-100">
                              {zone.sequestration}
                            </p>
                          </div>
                          <a
                            href={zone.mapsUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center text-sm font-medium text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors"
                            data-testid={`link-maps-${index}`}
                          >
                            <MapPin className="w-4 h-4 mr-2" />
                            📍 View on Maps
                          </a>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Activity with Enhanced Colors */}
      <Card className="bg-gradient-to-r from-slate-50 to-gray-100 dark:from-slate-950 dark:to-gray-900 border-slate-200 dark:border-slate-800">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-slate-900 dark:text-slate-100">
            ⚡ Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity) => {
              const IconComponent = activity.icon === "check" ? Check : TrendingUp;
              const colorClasses = {
                green: "bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900 dark:to-emerald-900 border-green-200 dark:border-green-800",
                blue: "bg-gradient-to-r from-blue-100 to-cyan-100 dark:from-blue-900 dark:to-cyan-900 border-blue-200 dark:border-blue-800",
              };
              const iconColors = {
                green: "bg-green-500 text-white",
                blue: "bg-blue-500 text-white",
              };

              return (
                <div
                  key={activity.id}
                  className={`flex items-center space-x-4 p-4 rounded-xl border-2 ${colorClasses[activity.color as keyof typeof colorClasses]} transition-all hover:scale-102 hover:shadow-md`}
                  data-testid={`activity-${activity.id}`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${iconColors[activity.color as keyof typeof iconColors]}`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{activity.message}</p>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">{activity.time}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
