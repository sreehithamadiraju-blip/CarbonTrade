import { MoreHorizontal } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import DashboardLayout from "./layout";

// Mock projects data for the current user
const mockProjects = [
  {
    id: "1",
    name: "Kerala Mangrove Restoration",
    location: "Kochi, Kerala",
    status: "approved",
    carbonSequestered: 45.2,
    date: "2024-01-15",
  },
  {
    id: "2",
    name: "Tamil Nadu Seagrass Project",
    location: "Rameswaram, Tamil Nadu",
    status: "pending",
    carbonSequestered: null,
    date: "2024-01-20",
  },
  {
    id: "3",
    name: "Goa Salt Marsh Initiative",
    location: "Panaji, Goa",
    status: "approved",
    carbonSequestered: 32.8,
    date: "2024-01-10",
  },
];

const getStatusBadge = (status: string) => {
  const statusConfig = {
    approved: {
      variant: "default" as const,
      className: "bg-green-500/20 text-green-400 hover:bg-green-500/30",
    },
    pending: {
      variant: "secondary" as const,
      className: "bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30",
    },
    rejected: {
      variant: "destructive" as const,
      className: "bg-red-500/20 text-red-400 hover:bg-red-500/30",
    },
  };

  const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending;

  return (
    <Badge variant={config.variant} className={config.className}>
      {status}
    </Badge>
  );
};

export default function MyProjects() {
  return (
    <DashboardLayout title="My Projects">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">
            My Projects & Rewards
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto" data-testid="projects-table">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-muted-foreground">Project Name</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground">Carbon Sequestered</TableHead>
                  <TableHead className="text-muted-foreground">Date</TableHead>
                  <TableHead className="text-muted-foreground">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockProjects.map((project) => (
                  <TableRow key={project.id} data-testid={`project-row-${project.id}`}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-foreground">{project.name}</p>
                        <p className="text-sm text-muted-foreground">{project.location}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(project.status)}
                    </TableCell>
                    <TableCell>
                      {project.carbonSequestered ? (
                        <span className="text-foreground">
                          {project.carbonSequestered} tons CO₂e
                        </span>
                      ) : (
                        <span className="text-muted-foreground">N/A</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="text-muted-foreground">{project.date}</span>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="p-1 text-muted-foreground hover:text-foreground"
                            data-testid={`actions-${project.id}`}
                          >
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem data-testid={`view-${project.id}`}>
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem data-testid={`edit-${project.id}`}>
                            Edit Project
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" data-testid={`delete-${project.id}`}>
                            Delete Project
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
