import { Award, Trophy, Star, Users, Leaf } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "./layout";
import { currentUser, rewardBadges } from "@/lib/data";

const iconMap = {
  award: Award,
  trophy: Trophy,
  star: Star,
  users: Users,
};

const colorMap = {
  green: "green-500",
  blue: "blue-500",
  purple: "purple-500",
  amber: "amber-500",
};

export default function Profile() {
  return (
    <DashboardLayout title="Profile">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* User Information */}
        <div className="lg:col-span-1">
          <Card className="bg-card border-border" data-testid="user-info-card">
            <CardContent className="p-6">
              <div className="text-center">
                <Avatar className="w-24 h-24 mx-auto mb-4">
                  <AvatarFallback className="bg-primary text-primary-foreground text-2xl font-bold">
                    {currentUser.avatar}
                  </AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-semibold text-foreground" data-testid="user-name">
                  {currentUser.name}
                </h3>
                <p className="text-muted-foreground" data-testid="user-email">
                  {currentUser.email}
                </p>
                <Badge className="bg-primary/20 text-primary mt-2" data-testid="user-role">
                  {currentUser.role}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* My Rewards and Tokenized Credits */}
        <div className="lg:col-span-2 space-y-6">
          {/* My Rewards */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-foreground">My Rewards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" data-testid="rewards-grid">
                {rewardBadges.map((badge) => {
                  const IconComponent = iconMap[badge.icon as keyof typeof iconMap];
                  const colorClass = colorMap[badge.color as keyof typeof colorMap];

                  return (
                    <div
                      key={badge.id}
                      className={`p-4 bg-${colorClass}/10 border border-${colorClass}/20 rounded-lg`}
                      data-testid={`reward-${badge.id}`}
                    >
                      <div className="flex items-center">
                        <div className={`w-10 h-10 bg-${colorClass}/20 rounded-lg flex items-center justify-center mr-3`}>
                          <IconComponent className={`w-5 h-5 text-${colorClass}`} />
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground">{badge.name}</h4>
                          <p className="text-sm text-muted-foreground">{badge.description}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Tokenized Carbon Credits */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-lg font-semibold text-foreground">
                Tokenized Carbon Credits
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg" data-testid="carbon-credits-card">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-2xl font-bold text-primary" data-testid="total-credits">
                      {currentUser.carbonCredits} C-BLUE
                    </p>
                    <p className="text-sm text-muted-foreground">Total Carbon Credits</p>
                  </div>
                  <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
                    <Leaf className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-4">
                  Each C-BLUE token represents 1 ton of CO₂ equivalent sequestered through verified
                  blue carbon ecosystem projects.
                </p>
                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
                  data-testid="button-view-testnet"
                >
                  View on Testnet
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
