import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Camera, Video, Upload } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import DashboardLayout from "./layout";

const projectSchema = z.object({
  name: z.string().min(2, "Project name must be at least 2 characters"),
  location: z.string().min(2, "Location must be at least 2 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
});

type ProjectFormData = z.infer<typeof projectSchema>;

export default function SubmitProject() {
  const [files, setFiles] = useState<File[]>([]);
  const { toast } = useToast();

  const form = useForm<ProjectFormData>({
    resolver: zodResolver(projectSchema),
    defaultValues: {
      name: "",
      location: "",
      description: "",
    },
  });

  const onSubmit = async (data: ProjectFormData) => {
    console.log("Project submission:", data);
    console.log("Files:", files);
    
    toast({
      title: "Project Submitted",
      description: "Your project has been submitted for review.",
    });

    form.reset();
    setFiles([]);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    setFiles(prev => [...prev, ...selectedFiles]);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <DashboardLayout title="Submit Project">
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-foreground">
            Submit New Plantation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Name</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter project name"
                          className="bg-input border-border"
                          data-testid="input-project-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter location"
                          className="bg-input border-border"
                          data-testid="input-location"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        rows={4}
                        placeholder="Describe your plantation project"
                        className="bg-input border-border"
                        data-testid="textarea-description"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Evidence Submission Section */}
              <div className="space-y-6">
                <h4 className="text-lg font-medium text-foreground">Evidence Submission</h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Photo Instructions */}
                  <div className="p-4 bg-muted rounded-lg" data-testid="photo-instructions">
                    <div className="flex items-center mb-3">
                      <Camera className="w-5 h-5 text-primary mr-2" />
                      <h5 className="font-medium text-foreground">Photo Requirements</h5>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Minimum of 6 high-quality photos</li>
                      <li>• Wide shots showing project area</li>
                      <li>• Close-up shots of plantations</li>
                      <li>• Before and after pictures</li>
                      <li>• Clear and well-lit images</li>
                    </ul>
                  </div>

                  {/* Video Instructions */}
                  <div className="p-4 bg-muted rounded-lg" data-testid="video-instructions">
                    <div className="flex items-center mb-3">
                      <Video className="w-5 h-5 text-primary mr-2" />
                      <h5 className="font-medium text-foreground">Video Requirements</h5>
                    </div>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>• Minimum of 5 high-quality videos</li>
                      <li>• At least 2 videos must be captured via drone</li>
                      <li>• Videos should show the planting process</li>
                      <li>• Concise (1-2 minutes each)</li>
                    </ul>
                  </div>
                </div>

                {/* File Upload Area */}
                <div className="file-upload-area p-8 rounded-lg text-center" data-testid="file-upload-area">
                  <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium text-foreground mb-2">
                    Drag and drop your files here
                  </p>
                  <p className="text-muted-foreground mb-4">or click to browse</p>
                  
                  <input
                    type="file"
                    multiple
                    accept="image/*,video/*"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload"
                    data-testid="input-files"
                  />
                  <label htmlFor="file-upload">
                    <Button
                      type="button"
                      className="bg-primary hover:bg-primary/90 text-primary-foreground"
                      asChild
                      data-testid="button-choose-files"
                    >
                      <span>Choose Files</span>
                    </Button>
                  </label>
                  
                  <p className="text-xs text-muted-foreground mt-4">
                    Supports: JPG, PNG, MP4, MOV (Max 100MB each)
                  </p>
                </div>

                {/* Selected Files */}
                {files.length > 0 && (
                  <div className="space-y-2" data-testid="selected-files">
                    <h5 className="font-medium text-foreground">Selected Files ({files.length})</h5>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {files.map((file, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-2 bg-muted rounded text-sm"
                          data-testid={`file-${index}`}
                        >
                          <span className="text-foreground truncate">{file.name}</span>
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(index)}
                            className="text-muted-foreground hover:text-foreground"
                            data-testid={`remove-file-${index}`}
                          >
                            ×
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium py-3"
                data-testid="button-submit-project"
              >
                Submit Project for Review
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </DashboardLayout>
  );
}
