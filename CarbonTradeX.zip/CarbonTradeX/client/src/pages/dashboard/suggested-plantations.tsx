import { Trees, Waves, Mountain, DollarSign, Clock, Leaf, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import DashboardLayout from "./layout";
import { ecosystems } from "@/lib/data";

const iconMap = {
  trees: Trees,
  waves: Waves,
  mountain: Mountain,
  "dollar-sign": DollarSign,
  clock: Clock,
  leaf: Leaf,
  "map-pin": MapPin,
};

const colorMap = {
  green: "green-500",
  blue: "blue-500",
  purple: "purple-500",
};

export default function SuggestedPlantations() {
  return (
    <DashboardLayout title="Suggested Plantations">
      <div className="space-y-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-foreground mb-2">
            Suggested Plantation Ecosystems
          </h2>
          <p className="text-muted-foreground">
            Learn about blue carbon ecosystems and their environmental benefits
          </p>
        </div>

        {ecosystems.map((ecosystem) => {
          const IconComponent = iconMap[ecosystem.icon as keyof typeof iconMap];
          const colorClass = colorMap[ecosystem.color as keyof typeof colorMap];

          return (
            <Card key={ecosystem.id} className="bg-card border-border" data-testid={`ecosystem-${ecosystem.id}`}>
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className={`w-12 h-12 bg-${colorClass}/20 rounded-lg flex items-center justify-center mr-4`}>
                    <IconComponent className={`w-6 h-6 text-${colorClass}`} />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-foreground">{ecosystem.name}</h3>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {ecosystem.species.map((species) => (
                        <Badge
                          key={species}
                          className="px-2 py-1 bg-primary/20 text-primary text-xs"
                          data-testid={`species-${species.toLowerCase()}`}
                        >
                          {species}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="space-y-3" data-testid={`economic-benefits-${ecosystem.id}`}>
                    <div className="flex items-center">
                      <DollarSign className="w-5 h-5 text-green-500 mr-2" />
                      <h4 className="font-medium text-foreground">Economic Benefits</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">{ecosystem.economicBenefits}</p>
                  </div>

                  <div className="space-y-3" data-testid={`growth-maturity-${ecosystem.id}`}>
                    <div className="flex items-center">
                      <Clock className="w-5 h-5 text-blue-500 mr-2" />
                      <h4 className="font-medium text-foreground">Growth & Maturity</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">{ecosystem.growthMaturity}</p>
                  </div>

                  <div className="space-y-3" data-testid={`carbon-sequestration-${ecosystem.id}`}>
                    <div className="flex items-center">
                      <Leaf className="w-5 h-5 text-green-500 mr-2" />
                      <h4 className="font-medium text-foreground">Carbon Sequestration Rate</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">{ecosystem.carbonSequestration}</p>
                  </div>

                  <div className="space-y-3" data-testid={`planting-zones-${ecosystem.id}`}>
                    <div className="flex items-center">
                      <MapPin className="w-5 h-5 text-blue-500 mr-2" />
                      <h4 className="font-medium text-foreground">Ideal Planting Zones</h4>
                    </div>
                    <p className="text-sm text-muted-foreground">{ecosystem.plantingZones}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </DashboardLayout>
  );
}
