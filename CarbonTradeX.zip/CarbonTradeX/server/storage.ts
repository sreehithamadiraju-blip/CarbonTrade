import { type User, type InsertUser, type Project, type InsertProject, type Transaction, type InsertTransaction } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUserProjects(userId: string): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;
  private transactions: Map<string, Transaction>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.transactions = new Map();
    this.initializeTestData();
  }

  private initializeTestData() {
    // Create test user
    const testUser: User = {
      id: "test-user-1",
      username: "john.doe",
      password: "password123",
      fullName: "John Doe",
      email: "john.doe@example.com",
      role: "individual",
      walletBalance: 45280,
      carbonCredits: 78,
      createdAt: new Date("2024-01-01"),
    };
    this.users.set(testUser.id, testUser);

    // Create test projects
    const testProjects: Project[] = [
      {
        id: "project-1",
        userId: testUser.id,
        name: "Kerala Mangrove Restoration",
        location: "Kochi, Kerala",
        description: "Large-scale mangrove restoration project in coastal Kerala",
        status: "approved",
        carbonSequestered: 45,
        submittedAt: new Date("2024-01-15"),
        approvedAt: new Date("2024-01-20"),
      },
      {
        id: "project-2",
        userId: testUser.id,
        name: "Tamil Nadu Seagrass Project",
        location: "Rameswaram, Tamil Nadu",
        description: "Seagrass meadow restoration in Palk Bay",
        status: "pending",
        carbonSequestered: null,
        submittedAt: new Date("2024-01-20"),
        approvedAt: null,
      },
      {
        id: "project-3",
        userId: testUser.id,
        name: "Goa Salt Marsh Initiative",
        location: "Panaji, Goa",
        description: "Salt marsh ecosystem restoration project",
        status: "approved",
        carbonSequestered: 33,
        submittedAt: new Date("2024-01-10"),
        approvedAt: new Date("2024-01-18"),
      },
    ];

    testProjects.forEach(project => {
      this.projects.set(project.id, project);
    });

    // Create test transactions
    const testTransactions: Transaction[] = [
      {
        id: "transaction-1",
        userId: testUser.id,
        type: "buy",
        amount: 25,
        value: 21875,
        status: "completed",
        createdAt: new Date("2024-01-20"),
      },
      {
        id: "transaction-2",
        userId: testUser.id,
        type: "sell",
        amount: 15,
        value: 13125,
        status: "completed",
        createdAt: new Date("2024-01-18"),
      },
    ];

    testTransactions.forEach(transaction => {
      this.transactions.set(transaction.id, transaction);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      walletBalance: 0,
      carbonCredits: 0,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      (project) => project.userId === userId,
    );
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = {
      ...insertProject,
      id,
      status: "pending",
      carbonSequestered: null,
      submittedAt: new Date(),
      approvedAt: null,
    };
    this.projects.set(id, project);
    return project;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values()).filter(
      (transaction) => transaction.userId === userId,
    );
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.transactions.set(id, transaction);
    return transaction;
  }
}

export const storage = new MemStorage();
